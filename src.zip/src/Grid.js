import './Grid.css';
function Grid(){
    return(
        <div id ="main">
        <div id="gri">
        <div id="b1"><img src="https://wallpapercave.com/wp/wp8998809.jpg" width={300} height={200} alt="vf"/><br/>
        <h2>Sunrisers Hyderabad
</h2></div>
<div id="b2"><img src="https://timesofindia.indiatimes.com/photo/67191193.cms" width={300} height={200} alt="vf"/><br/><h2>Chennai Super Kings</h2></div>
<div id="b3"><img src="https://th.bing.com/th/id/OIP.pZcYF1HMTVVGUa6raEhKDgAAAA?w=338&h=300&rs=1&pid=ImgDetMain" width={300} height={200} alt="vf"/><br/>
        <h2>Mumbai Indians</h2></div>
<div id="b4"><img src="https://e1.pxfuel.com/desktop-wallpaper/436/167/desktop-wallpaper-rcb-logo-ipl-logo-thumbnail.jpg" width={300} height={200} alt="vf"/><br/>
        <h2>Royal Challengers Bangalore</h2></div>
<div id="b5"><img src="https://th.bing.com/th/id/R.c4dd2839d2e90f13892d35b95e23c436?rik=cEqFL8xqBlJ5ug&riu=http%3a%2f%2f1.bp.blogspot.com%2f-yO1zS_YxUj8%2fUWcKVWeAUgI%2fAAAAAAAAGFk%2fYtrp97kskGU%2fs1600%2fKolkata%2bKnight%2bRiders%2bLogo.jpg&ehk=lUXvqSseuo3WhpulAQtTXEF9GYpPbbGQvOpN%2b6AUhkY%3d&risl=&pid=ImgRaw&r=0" width={300} height={200} alt="vf"/><br/>
        <h2>Kolkata Knight Riders</h2></div>
<div id="b6"><img src="https://th.bing.com/th/id/OIP.ggoHyfOQgje-WlHxoxuvwgHaHa?rs=1&pid=ImgDetMain" width={300} height={200} alt="vf"/><br/>
        <h2>Punjab Kings</h2></div>
<div id="b7"><img src="https://img.jagranjosh.com/imported/images/E/GK/Rajasthan%20Royals%20Team%20profile.jpg" width={300} height={200} alt="vf"/><br/>
        <h2>Rajasthan Royals</h2></div>
<div id="b8"><img src="https://d3pc1xvrcw35tl.cloudfront.net/ln/images/420x315/gujarat-titans-logo_202202334665.jpeg" width={300} height={200} alt="vf"/><br/>
        <h2>Gujarat Titans</h2></div>
<div id="b9"><img src="https://aniportalimages.s3.amazonaws.com/media/details/Capturelshkjsd2022013111314320220131113747.jpg" width={300} height={200} alt="vf"/><br/>
        <h2>Lucknow Super Giants</h2></div>
<div id="b10"><img src="https://th.bing.com/th/id/OIP.wxxaCbTTYtDhKdnBFWkLSwHaFj?rs=1&pid=ImgDetMain" width={300} height={200} alt="vf"/><br/>
        <h2>Delhi Capitals</h2></div>
        </div>
        </div>
    )
}
export default Grid;