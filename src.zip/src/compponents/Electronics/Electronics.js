function Electronics(){
    return(
        <div>Electronics</div>
    )
}
export default Electronics;