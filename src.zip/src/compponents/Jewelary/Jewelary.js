function Jewelary(){
    return(
        <div>Jewelary</div>
    )
}
export default Jewelary;