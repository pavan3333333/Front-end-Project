import React from "react"
function PagenF(){
    return(
        <div>
           <img src="https://cdn.acodez.in/wp-content/uploads/2022/03/Using-Illustrations-on-a-404-Page-Makes-it-Delightful.png" alt="rf"/> 
        </div>
    )
}
export default PagenF;