function Mensclothing(){
    return(
        <div>Mensclothing</div>
    )
}
export default Mensclothing;