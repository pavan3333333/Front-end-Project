import "./App.css";
function App(){
  return(
            <div id="con333">
              <div id="box111" ><h1 className="text-center">INDAIN PREMIER LEAGUE </h1></div>
              <div id="box222">
              <a id="a1" href="https://www.cricbuzz.com/cricket-stats/icc-rankings/men/batting">Matches</a>
              <a id="a1" href="https://www.cricbuzz.com/cricket-stats/icc-rankings/men/batting">Teams</a>            
              <a id="a1" href="https://www.cricbuzz.com/cricket-stats/icc-rankings/men/batting">Stats</a>
              <a id="a1" href="https://www.cricbuzz.com/cricket-stats/icc-rankings/men/batting">Table</a>
              <a id="a1" href="https://www.cricbuzz.com/cricket-stats/icc-rankings/men/batting">Venues</a>
<input type="search" placeholder="search" style={{width:"250px",height:"30px"}}/>
              </div>
            </div>  
  )
  }
export default App;