function Team(){
    return(
        <div style={{ 
            display:"flex",
            flexDirection:"column",
            justifyContent:"center",
            alignItems:"center",
            color:"white",
            backgroundColor:"black"
        }}>
            <h2>IPL TEAMS</h2>
        </div>
    )
}
export default Team;