function Ex()
{
    return(
        <div>
            <p>Hello</p>
        </div>
    )
};
export default Ex;