function Team(){
    return(
        <div style={{ 
            display:"flex",
            flexDirection:"column",
            justifyContent:"center",
            alignItems:"center",
        }}>
            <h2>IPL TEAMS</h2>
        </div>
    )
}
export default Team();