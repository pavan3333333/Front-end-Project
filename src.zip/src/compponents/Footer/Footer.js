function Footer()
{
    return(
        <div>
            <button className="btn btn-outline-success">fcdcd</button>
        </div>
    )
}
export default Footer;