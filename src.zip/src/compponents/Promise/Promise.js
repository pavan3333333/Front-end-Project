var pobj = new Promise(function(resolve,reject){
resolve("pavan");
});

console.log(pobj);